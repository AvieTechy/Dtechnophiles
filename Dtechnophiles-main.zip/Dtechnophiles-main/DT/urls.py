from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from django.conf.urls import include

from manager.views import (
    index, contract, worksheet, report, diary, project, plan, week1, week2
)

urlpatterns = [
    path('', index, name="index"),
    path('contract/', contract, name="contract"),
    path('worksheet/', worksheet, name="worksheet"),
    path('report/', report, name="report"),
    path('diary/', diary, name="diary"),
    path('project/', project, name="project"),
    path('plan/', plan, name="plan"),
    path('week1/', week1, name="week1"),
    path('week2/', week2, name="week2"),

] +static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)+static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)

